<div class="header-top">
	<div class="container">
		<div class="top-nav">
			<div class="logo">
				<h1>My Tour</h1>
			</div>

			<div class="menu">
				<ul id="nav">
					<li><a href="logout.php">Log Out</a></li>
					<div class="clearfix"></div>
				</ul>
			</div>
		</div>

		<div class="clearfix"> </div>
	</div>
</div>
