<div class="header-top">
	<div class="container">
		<div class="top-nav">
			<div class="logo">
				<h1>Пътешестие</h1>
			</div>
			<div class="menu">
				<ul id="nav">
					<li><a href="index.php#section-1">Начало</a></li>
					<li><a href="index.php#section-2">За нас</a></li>
					<li><a href="index.php#section-3">Галерия</a></li>


					<li><a href="category.php">Категории</a></li>

					<li><a href="Admin/loginform.php">Вход за служители</a></li>

					<div class="clearfix"></div>
				</ul>
			</div>
		</div>

		<div class="clearfix"></div>
	</div>
</div>
